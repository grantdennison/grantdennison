Hello All and welcome to my page.

I am an engineer currently working in the railway industry, where I am responsible for ensuring the smooth operation of trains. My role involves online monitoring of trains, conducting in-depth fault finding, and programming to maintain their functionality. While I have a strong background in engineering, my true passion lies in programming, specifically in JavaScript.

I have developed a deep understanding of JavaScript and I am familiar with popular frameworks and libraries such as React, Node.js, Express, Canvas, and Socket.io. Despite not having commercial experience in programming, I am eager to transition into a career in JavaScript programming. I am confident in my skills and believe that with the right opportunity, I can make a significant impact.

I am seeking a company that is willing to give me a chance to prove myself as a JavaScript developer. I am open to part-time or voluntary work initially to gain practical experience and demonstrate my capabilities. I am dedicated and motivated to succeed in this field, and I am willing to go the extra mile to prove my worth.

I bring a unique combination of technical problem-solving skills from my engineering background along with a strong foundation in JavaScript development. I am a quick learner, adaptable, and possess excellent analytical skills. I thrive in challenging environments and enjoy working collaboratively to find innovative solutions.

If given the opportunity, I am confident that I can contribute effectively to your team and help drive the success of your projects. I am excited about the prospect of starting a fulfilling career in programming and I am committed to continuous learning and growth.
